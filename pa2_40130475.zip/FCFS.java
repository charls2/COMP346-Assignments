package A2;

import A1.STATE;

import java.util.*;

public class FCFS {

    private int time;
    private Queue<PCB> readyQ;
    private ArrayList<CPU> cpus;
    private List<PCB> pcbList;

    private boolean done = false;

    public FCFS() {
        System.out.println("\n********** FCFS **********");

        time = CPUScheduler.getTime();
        readyQ = CPUScheduler.getReadyQueue();
        pcbList = CPUScheduler.getPCBList();
        cpus = CPUScheduler.getCpus();
    }

    public void begin() {

        do {

            if (!pcbList.isEmpty()) sortPCBList(pcbList);

            System.out.println("\n**** SYSTEM TIME: " + time + " ****");

            for (CPU cpu : CPUScheduler.getCpus()) {

                // assign a process to an available CPU Core
                if (!cpu.isOccupied()) {
                    PCB pcbFromList = null;

                    if (!pcbList.isEmpty()) {
                        pcbFromList = pcbList.get(0);
                    }

                    if (!pcbList.isEmpty()
                            && time == pcbFromList.getProcess().getArrivalTime()
                            && !pcbFromList.getState().equals(STATE.RUNNING)) {
                        readyQ.add(pcbFromList);
                        //pcbList.remove(pcbFromList);

                    }
                    PCB currentProcess = null;

                    if (!readyQ.isEmpty()) {
                        currentProcess = readyQ.poll();
                    }

                    cpu.setPCB(currentProcess);
                    execute(cpu);

                    // Clear CPUs if process complete
                    CPUScheduler.clearCPU(cpu);

                } else {
                    // if cpu is in use
                    execute(cpu);
                    CPUScheduler.clearCPU(cpu);
                }
            }
            CPUScheduler.displayReadyQueue();
            CPUScheduler.displayCPUs();

            tick();
//            if (time == 20) return;
        } while (!readyQ.isEmpty() || !pcbList.isEmpty());
        System.out.print("\n****** SYSTEM TERMINATING (FCFS ALGORITHM) ******");
    }

    public void execute(CPU cpu) {
//        int arrivalTime = cpu.getPCB().getProcess().getArrivalTime();
//        int burstTime = cpu.getPCB().getProcess().getBurstTime();

        if (cpu.getPCB() == null)
            return;

        cpu.getPCB().setState(STATE.RUNNING);
        cpu.setPCB(cpu.getPCB());
        cpu.setOccupied(true);

        // Check if IO at system time
//        if (cpu.getPCB().getProcess().checkIO()) {
//            // is IO
//
//        }

        // Check if reached burst
        if (cpu.getPCB().getPcounter() == cpu.getPCB().getProcess().getBurstTime()) {
            cpu.getPCB().getProcess().setComplete(true);
        }

        if (cpu.getPCB().getProcess().isCompleted()) {
            System.out.println("CPU #: " + cpu.getKey() + " [COMPLETED: "
                    + cpu.getPCB().getPid() + "]");
            cpu.getPCB().setState(STATE.TERMINATED);
            //System.out.println("Process : " + cpu.getPCB().getPid() + ", STATE: " + cpu.getPCB().getState());
//            pcbList.add(cpu.getPCB());
            cpu.setOccupied(false);
            cpu.setPCB(null);
            return;
        }
        //System.out.println("CPU #: " + cpu.getKey() + " [Currently Executing: " + cpu.getPCB().getPid() + " Prog Counter: " + progCounter + "]");
        cpu.getPCB().setPcounter(cpu.getPCB().getPcounter() + 1);
        //pcbList.add(cpu.getPCB());
        //System.out.println("Process : " + cpu.getPCB().getPid() + ", STATE: " + cpu.getPCB().getState());

    }

    public void tick() {
        time++;
    }

    public List<PCB> sortPCBList(List<PCB> pcbList) {
        pcbList.sort(Comparator.comparingInt(o -> o.getProcess().getArrivalTime()));

        return pcbList;
    }
//    private void firstArrived(List<PCB> pcbList, PCB pcbFromList) {
//        pcbList.remove(pcbFromList);
//        while (!pcbList.isEmpty() && pcbList.get(0).getProcess().getArrivalTime() <= time) {
//            PCB arrivedProcess = pcbList.remove(0);
//            readyQ.add(arrivedProcess);
//        }
////        pcbList.add(pcbFromList);
//    }
}

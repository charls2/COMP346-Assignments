public enum STATE {
    NEW,
    RUNNING,
    WAITING,
    READY,
    TERMINATED
}
